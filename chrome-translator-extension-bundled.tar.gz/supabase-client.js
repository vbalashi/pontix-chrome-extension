// Supabase client configuration for Chrome Extension
// Uses bundled Supabase library

// Supabase configuration
const SUPABASE_CONFIG = {
    url: 'https://iyfwymlzdwtqruibeujc.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Iml5Znd5bWx6ZHd0cXJ1aWJldWpjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzMxNDEzOTQsImV4cCI6MjA0ODcxNzM5NH0.hBU0I1Yfl1FyaEIRZWnKr3cBOhJ05KL7eQWFk0wJcPQ'
};

// Initialize Supabase client
let supabaseClient = null;
let isLocalMode = false;

// Check if we're running in a supported environment
function getExtensionRedirectUrl() {
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL) {
        return chrome.runtime.getURL('sidebar.html');
    }
    return window.location.origin + '/sidebar.html';
}

// Initialize the Supabase client
function initializeSupabase() {
    if (typeof supabase === 'undefined') {
        console.warn('🔐 Supabase library not loaded. Running in local-only mode.');
        isLocalMode = true;
        return null;
    }
    
    if (!supabaseClient) {
        try {
            supabaseClient = supabase.createClient(SUPABASE_CONFIG.url, SUPABASE_CONFIG.anonKey, {
                auth: {
                    autoRefreshToken: true,
                    persistSession: true,
                    detectSessionInUrl: false, // Important for Chrome extensions
                    storage: {
                        // Custom storage adapter for Chrome extension
                        getItem: async (key) => {
                            return new Promise((resolve) => {
                                if (typeof chrome !== 'undefined' && chrome.storage) {
                                    chrome.storage.local.get([key], (result) => {
                                        resolve(result[key] || null);
                                    });
                                } else {
                                    resolve(localStorage.getItem(key));
                                }
                            });
                        },
                        setItem: async (key, value) => {
                            return new Promise((resolve) => {
                                if (typeof chrome !== 'undefined' && chrome.storage) {
                                    chrome.storage.local.set({ [key]: value }, () => {
                                        resolve();
                                    });
                                } else {
                                    localStorage.setItem(key, value);
                                    resolve();
                                }
                            });
                        },
                        removeItem: async (key) => {
                            return new Promise((resolve) => {
                                if (typeof chrome !== 'undefined' && chrome.storage) {
                                    chrome.storage.local.remove([key], () => {
                                        resolve();
                                    });
                                } else {
                                    localStorage.removeItem(key);
                                    resolve();
                                }
                            });
                        }
                    }
                }
            });
            
            console.log('🔐 Supabase client initialized successfully');
            isLocalMode = false;
        } catch (error) {
            console.warn('🔐 Failed to initialize Supabase client, falling back to local mode:', error);
            isLocalMode = true;
            supabaseClient = null;
        }
    }
    
    return supabaseClient;
}

// Get the current Supabase client instance
function getSupabaseClient() {
    if (!supabaseClient && !isLocalMode) {
        return initializeSupabase();
    }
    return supabaseClient;
}

// Check if we're in local mode
function isInLocalMode() {
    return isLocalMode || !supabaseClient;
}

// Enable cloud sync (now just initializes since library is bundled)
async function enableCloudSync() {
    try {
        console.log('🔄 Enabling cloud sync...');
        
        const client = initializeSupabase();
        if (client) {
            console.log('✅ Cloud sync enabled successfully');
            return { success: true, error: null };
        } else {
            throw new Error('Failed to initialize Supabase client');
        }
        
    } catch (error) {
        console.error('❌ Failed to enable cloud sync:', error);
        return { success: false, error: error.message };
    }
}

// Authentication functions with local mode fallback
async function signUp(email, password) {
    if (isInLocalMode()) {
        return { error: 'Cloud sync not available. Extension running in local mode.' };
    }
    
    const client = getSupabaseClient();
    if (!client) return { error: 'Supabase client not available' };
    
    try {
        const { data, error } = await client.auth.signUp({
            email,
            password,
            options: {
                emailRedirectTo: getExtensionRedirectUrl()
            }
        });
        
        if (error) {
            console.error('🔐 Sign up error:', error);
            return { error: error.message };
        }
        
        console.log('🔐 Sign up successful:', data);
        return { data, error: null };
        
    } catch (err) {
        console.error('🔐 Sign up exception:', err);
        return { error: 'Sign up failed. Please try again.' };
    }
}

async function signIn(email, password) {
    if (isInLocalMode()) {
        return { error: 'Cloud sync not available. Extension running in local mode.' };
    }
    
    const client = getSupabaseClient();
    if (!client) return { error: 'Supabase client not available' };
    
    try {
        const { data, error } = await client.auth.signInWithPassword({
            email,
            password
        });
        
        if (error) {
            console.error('🔐 Sign in error:', error);
            return { error: error.message };
        }
        
        console.log('🔐 Sign in successful:', data);
        return { data, error: null };
        
    } catch (err) {
        console.error('🔐 Sign in exception:', err);
        return { error: 'Sign in failed. Please try again.' };
    }
}

async function signUpWithOtp(email) {
    if (isInLocalMode()) {
        return { error: 'Cloud sync not available. Extension running in local mode.' };
    }
    
    const client = getSupabaseClient();
    if (!client) return { error: 'Supabase client not available' };
    
    try {
        const { data, error } = await client.auth.signUp({
            email,
            options: {
                emailRedirectTo: getExtensionRedirectUrl()
            }
        });
        
        if (error) {
            console.error('🔐 Sign up with OTP error:', error);
            return { error: error.message };
        }
        
        console.log('🔐 Sign up with OTP successful:', data);
        return { data, error: null };
        
    } catch (err) {
        console.error('🔐 Sign up with OTP exception:', err);
        return { error: 'Sign up failed. Please try again.' };
    }
}

async function signInWithOtp(email) {
    if (isInLocalMode()) {
        return { error: 'Cloud sync not available. Extension running in local mode.' };
    }
    
    const client = getSupabaseClient();
    if (!client) return { error: 'Supabase client not available' };
    
    try {
        const { data, error } = await client.auth.signInWithOtp({
            email,
            options: {
                emailRedirectTo: getExtensionRedirectUrl()
            }
        });
        
        if (error) {
            console.error('🔐 Sign in with OTP error:', error);
            return { error: error.message };
        }
        
        console.log('🔐 Sign in with OTP successful:', data);
        return { data, error: null };
        
    } catch (err) {
        console.error('🔐 Sign in with OTP exception:', err);
        return { error: 'Sign in failed. Please try again.' };
    }
}

async function verifyOtp(email, token, type = 'email') {
    if (isInLocalMode()) {
        return { error: 'Cloud sync not available. Extension running in local mode.' };
    }
    
    const client = getSupabaseClient();
    if (!client) return { error: 'Supabase client not available' };
    
    try {
        const { data, error } = await client.auth.verifyOtp({
            email,
            token,
            type
        });
        
        if (error) {
            console.error('🔐 OTP verification error:', error);
            return { error: error.message };
        }
        
        console.log('🔐 OTP verification successful:', data);
        return { data, error: null };
        
    } catch (err) {
        console.error('🔐 OTP verification exception:', err);
        return { error: 'Verification failed. Please try again.' };
    }
}

async function signOut() {
    if (isInLocalMode()) {
        return { error: 'Cloud sync not available. Extension running in local mode.' };
    }
    
    const client = getSupabaseClient();
    if (!client) return { error: 'Supabase client not available' };
    
    try {
        const { error } = await client.auth.signOut();
        
        if (error) {
            console.error('🔐 Sign out error:', error);
            return { error: error.message };
        }
        
        console.log('🔐 Sign out successful');
        return { error: null };
        
    } catch (err) {
        console.error('🔐 Sign out exception:', err);
        return { error: 'Sign out failed. Please try again.' };
    }
}

async function getCurrentUser() {
    if (isInLocalMode()) {
        return { data: { user: null }, error: null };
    }
    
    const client = getSupabaseClient();
    if (!client) return { data: { user: null }, error: 'Supabase client not available' };
    
    try {
        const { data, error } = await client.auth.getUser();
        return { data, error: error ? error.message : null };
        
    } catch (err) {
        console.error('🔐 Get current user exception:', err);
        return { data: { user: null }, error: 'Failed to get user.' };
    }
}

async function getCurrentSession() {
    if (isInLocalMode()) {
        return { data: { session: null }, error: null };
    }
    
    const client = getSupabaseClient();
    if (!client) return { data: { session: null }, error: 'Supabase client not available' };
    
    try {
        const { data, error } = await client.auth.getSession();
        return { data, error: error ? error.message : null };
        
    } catch (err) {
        console.error('🔐 Get current session exception:', err);
        return { data: { session: null }, error: 'Failed to get session.' };
    }
}

// Data management functions
async function saveUserSettings(settings) {
    if (isInLocalMode()) {
        return { error: 'Cloud sync not available. Extension running in local mode.' };
    }
    
    const client = getSupabaseClient();
    if (!client) return { error: 'Supabase client not available' };
    
    try {
        const { data: userData, error: userError } = await client.auth.getUser();
        if (userError || !userData.user) {
            return { error: 'User not authenticated' };
        }
        
        const { data, error } = await client
            .from('user_settings')
            .upsert({
                user_id: userData.user.id,
                max_word_count: settings.maxWordCount,
                debug_selection: settings.debugSelection,
                default_target_language: settings.defaultTargetLanguage,
                enabled_providers: settings.enabledProviders,
                api_keys: settings.apiKeys,
                updated_at: new Date().toISOString()
            });
        
        if (error) {
            console.error('🔄 Save settings error:', error);
            return { error: error.message };
        }
        
        console.log('🔄 Settings saved successfully');
        return { data, error: null };
        
    } catch (err) {
        console.error('🔄 Save settings exception:', err);
        return { error: 'Failed to save settings.' };
    }
}

async function loadUserSettings() {
    if (isInLocalMode()) {
        return { data: null, error: 'Cloud sync not available' };
    }
    
    const client = getSupabaseClient();
    if (!client) return { data: null, error: 'Supabase client not available' };
    
    try {
        const { data: userData, error: userError } = await client.auth.getUser();
        if (userError || !userData.user) {
            return { data: null, error: 'User not authenticated' };
        }
        
        const { data, error } = await client
            .from('user_settings')
            .select('*')
            .eq('user_id', userData.user.id)
            .single();
        
        if (error && error.code !== 'PGRST116') { // PGRST116 = no rows found
            console.error('🔄 Load settings error:', error);
            return { data: null, error: error.message };
        }
        
        console.log('🔄 Settings loaded successfully');
        return { data, error: null };
        
    } catch (err) {
        console.error('🔄 Load settings exception:', err);
        return { data: null, error: 'Failed to load settings.' };
    }
}

async function saveUserProfile(profileName, profileSettings, isCurrent = false) {
    if (isInLocalMode()) {
        return { error: 'Cloud sync not available. Extension running in local mode.' };
    }
    
    const client = getSupabaseClient();
    if (!client) return { error: 'Supabase client not available' };
    
    try {
        const { data: userData, error: userError } = await client.auth.getUser();
        if (userError || !userData.user) {
            return { error: 'User not authenticated' };
        }
        
        // If this is the current profile, mark all others as not current
        if (isCurrent) {
            await client
                .from('user_profiles')
                .update({ is_current: false })
                .eq('user_id', userData.user.id);
        }
        
        const { data, error } = await client
            .from('user_profiles')
            .upsert({
                user_id: userData.user.id,
                profile_name: profileName,
                settings: profileSettings,
                is_current: isCurrent,
                updated_at: new Date().toISOString()
            });
        
        if (error) {
            console.error('🔄 Save profile error:', error);
            return { error: error.message };
        }
        
        console.log('🔄 Profile saved successfully');
        return { data, error: null };
        
    } catch (err) {
        console.error('🔄 Save profile exception:', err);
        return { error: 'Failed to save profile.' };
    }
}

async function loadUserProfiles() {
    if (isInLocalMode()) {
        return { data: [], error: 'Cloud sync not available' };
    }
    
    const client = getSupabaseClient();
    if (!client) return { data: [], error: 'Supabase client not available' };
    
    try {
        const { data: userData, error: userError } = await client.auth.getUser();
        if (userError || !userData.user) {
            return { data: [], error: 'User not authenticated' };
        }
        
        const { data, error } = await client
            .from('user_profiles')
            .select('*')
            .eq('user_id', userData.user.id);
        
        if (error) {
            console.error('🔄 Load profiles error:', error);
            return { data: [], error: error.message };
        }
        
        console.log('🔄 Profiles loaded successfully');
        return { data: data || [], error: null };
        
    } catch (err) {
        console.error('🔄 Load profiles exception:', err);
        return { data: [], error: 'Failed to load profiles.' };
    }
}

async function deleteUserProfile(profileName) {
    if (isInLocalMode()) {
        return { error: 'Cloud sync not available. Extension running in local mode.' };
    }
    
    const client = getSupabaseClient();
    if (!client) return { error: 'Supabase client not available' };
    
    try {
        const { data: userData, error: userError } = await client.auth.getUser();
        if (userError || !userData.user) {
            return { error: 'User not authenticated' };
        }
        
        const { data, error } = await client
            .from('user_profiles')
            .delete()
            .eq('user_id', userData.user.id)
            .eq('profile_name', profileName);
        
        if (error) {
            console.error('🔄 Delete profile error:', error);
            return { error: error.message };
        }
        
        console.log('🔄 Profile deleted successfully');
        return { data, error: null };
        
    } catch (err) {
        console.error('🔄 Delete profile exception:', err);
        return { error: 'Failed to delete profile.' };
    }
}

// Expose the API through window.SupabaseAuth
window.SupabaseAuth = {
    initializeSupabase,
    getSupabaseClient,
    isInLocalMode,
    enableCloudSync,
    signUp,
    signIn,
    signUpWithOtp,
    signInWithOtp,
    verifyOtp,
    signOut,
    getCurrentUser,
    getCurrentSession,
    saveUserSettings,
    loadUserSettings,
    saveUserProfile,
    loadUserProfiles,
    deleteUserProfile
};

// Auto-initialize when the script loads
document.addEventListener('DOMContentLoaded', () => {
    console.log('🔐 Supabase client script loaded');
    initializeSupabase();
}); 